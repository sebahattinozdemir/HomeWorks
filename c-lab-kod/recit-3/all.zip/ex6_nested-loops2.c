/* Example 6: Find these triplets! */

#include <math.h>
#include <stdio.h>
#define LIMIT 25

int main(void) {

	int a, b, c, c_sqr;

	for (a = 1; a < LIMIT; a++) {

		//another loops is required here
			// then some conditionals in the loop

	}
}