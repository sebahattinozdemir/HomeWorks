/* Example 2: Take two integers as input and print the greatest common divisor of them.*/

#include <stdio.h>

int main() {

	int a, b;

	printf("Enter two integers: ");
	scanf("%d %d", &a, &b);

	while (a != b) {

		// do the calculations
		
	}

	printf("%d\n", a);

	return 0;
}
