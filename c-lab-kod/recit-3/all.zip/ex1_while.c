#include <stdio.h>

int main() {

    char c;
    int vowelcount = charcount = 0;

    // c = 'A';
    // printf("A: %d\n", c);
    // c = 'Z';
    // printf("Z: %d\n", c);
    // c = 'a';
    // printf("a: %d\n", c);
    // c = 'z';
    // printf("z: %d\n", c);

    // your program will get input as file (./exe < file.txt)
    while ((c = getchar()) != EOF) {

        // do the calculations

    }

    printf("vowels = %f\n", (float)vowelcount/charcount);
}