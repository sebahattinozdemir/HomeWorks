/* Draw a pyramide */
/* # */
/* ## */
/* ### */
/* #### */
/* ##### */
/* ###### */

#include <stdio.h>

int main(){

	int size;
	int i,j;

	printf("Please enter the size of your pyramid:\n");
	scanf("%d",&size);

	for (i = 0; i <= size; i++) {

		// another loop is required here

	}


	return 0;
}