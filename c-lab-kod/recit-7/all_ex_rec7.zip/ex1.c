#include <stdio.h>

/* define a structure type struct birthday */

/* declare friendBday to be a variable of this type */


int main(void)
{

/* declare myBday to be of type struct birthday
and initialize it */

/* assign myBday to friendBday */

/* access members of friendBday and print */

return 0;
}
